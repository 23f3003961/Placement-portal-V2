import axios from 'axios'

const api = axios.create({
  baseURL: 'http://localhost:5001/api' // used 5001 port as port 5000 is used by some other app
                                      // that was running in the system simultaneously.
})

api.interceptors.request.use(config => {
  const token = localStorage.getItem('token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

api.interceptors.response.use(
  response => response,
  error => {
    if (error.response && error.response.status === 401) {
      localStorage.clear()
      window.location.href = '/login'
    }
    return Promise.reject(error)
  }
)

export default api