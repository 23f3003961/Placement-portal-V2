<template>
  <div class="container mt-4">
    <h3>Student Dashboard</h3>

    <!-- Edit Profile -->
    <div class="card mt-3 mb-4">
      <div class="card-header d-flex justify-content-between align-items-center">
        <span>My Profile</span>
        <button class="btn btn-sm btn-outline-primary" @click="toggleProfile">
          {{ showProfile ? 'Hide' : 'Edit Profile' }}
        </button>
      </div>
      <div class="card-body" v-if="showProfile && profile">
        <div v-if="profileSuccess" class="alert alert-success">Profile updated successfully.</div>
        <div v-if="profileError" class="alert alert-danger">{{ profileError }}</div>
        <div class="row">
          <div class="col-md-6 mb-3">
            <label class="form-label">Name</label>
            <input type="text" class="form-control" v-model="profile.name" />
          </div>
          <div class="col-md-6 mb-3">
            <label class="form-label">Branch</label>
            <input type="text" class="form-control" v-model="profile.branch" />
          </div>
          <div class="col-md-6 mb-3">
            <label class="form-label">CGPA</label>
            <input type="number" step="0.1" class="form-control" v-model="profile.cgpa" />
          </div>
          <div class="col-md-6 mb-3">
            <label class="form-label">Year (1-4)</label>
            <input type="number" min="1" max="4" class="form-control" v-model="profile.year" />
          </div>
        </div>
        <button class="btn btn-primary me-3" @click="updateProfile">Save Changes</button>

        <div class="mt-3">
          <label class="form-label">Upload Resume (PDF only)</label>
          <input type="file" class="form-control" accept=".pdf" @change="onFileChange" />
          <button class="btn btn-secondary mt-2" @click="uploadResume" :disabled="!resumeFile">
            Upload Resume
          </button>
          <span v-if="resumeSuccess" class="ms-3 text-success">Resume uploaded!</span>
          <p v-if="profile.resume_path" class="mt-2 text-muted small">
            Resume on file: {{ profile.resume_path.split('/').pop() }}
          </p>
        </div>
      </div>
    </div>

    <!-- Search and Filter -->
    <h5>Available Placement Drives</h5>
    <div class="row mb-3">
      <div class="col-md-4">
        <input
          type="text"
          class="form-control"
          placeholder="Search by job title or company..."
          v-model="filters.search"
          @input="loadDrives"
        />
      </div>
      <div class="col-md-3">
        <input
          type="text"
          class="form-control"
          placeholder="Filter by branch..."
          v-model="filters.branch"
          @input="loadDrives"
        />
      </div>
      <div class="col-md-2">
        <input
          type="number"
          class="form-control"
          placeholder="Year (1-4)"
          v-model="filters.year"
          @input="loadDrives"
        />
      </div>
      <div class="col-md-3">
        <button class="btn btn-outline-secondary w-100" @click="clearFilters">Clear Filters</button>
      </div>
    </div>

    <div v-if="drives.length === 0" class="text-muted">No approved drives available.</div>
    <table v-else class="table table-bordered mt-2">
      <thead>
        <tr>
          <th>Job Title</th>
          <th>Company</th>
          <th>Branch</th>
          <th>Min CGPA</th>
          <th>Year</th>
          <th>Deadline</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="drive in drives" :key="drive.id">
          <td>{{ drive.job_title }}</td>
          <td>{{ drive.company_name }}</td>
          <td>{{ drive.eligibility_branch }}</td>
          <td>{{ drive.min_cgpa }}</td>
          <td>{{ drive.eligibility_year }}</td>
          <td>{{ new Date(drive.deadline).toLocaleDateString() }}</td>
          <td>
            <button class="btn btn-primary btn-sm" @click="apply(drive.id)">Apply</button>
          </td>
        </tr>
      </tbody>
    </table>

    <hr>

    <!-- My Applications -->
    <h5>My Applications</h5>
    <div v-if="applications.length === 0" class="text-muted">You have not applied to any drives yet.</div>
    <table v-else class="table table-bordered mt-2">
      <thead>
        <tr>
          <th>Job Title</th>
          <th>Company</th>
          <th>Status</th>
          <th>Applied On</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="app in applications" :key="app.application_id">
          <td>{{ app.job_title }}</td>
          <td>{{ app.company_name }}</td>
          <td>
            <span :class="{
              'badge bg-secondary': app.status === 'APPLIED',
              'badge bg-warning text-dark': app.status === 'SHORTLISTED',
              'badge bg-success': app.status === 'SELECTED',
              'badge bg-danger': app.status === 'REJECTED'
            }">{{ app.status }}</span>
          </td>
          <td>{{ new Date(app.applied_at).toLocaleDateString() }}</td>
        </tr>
      </tbody>
    </table>

    <div class="mt-3">
      <button class="btn btn-secondary" @click="exportApplications">
        Export My Applications (CSV)
      </button>
      <span v-if="exportMessage" class="ms-3 text-success">{{ exportMessage }}</span>
    </div>

  </div>
</template>

<script>
import api from "../../services/api"

export default {
  name: "StudentDashboard",
  data() {
    return {
      drives: [],
      applications: [],
      profile: null,
      showProfile: false,
      profileSuccess: false,
      profileError: "",
      resumeFile: null,
      resumeSuccess: false,
      exportMessage: "",
      filters: {
        search: "",
        branch: "",
        year: ""
      }
    }
  },
  async mounted() {
    await this.loadDrives()
    await this.loadApplications()
    await this.loadProfile()
  },
  methods: {
    async loadDrives() {
      try {
        const params = new URLSearchParams()
        if (this.filters.search) params.append("search", this.filters.search)
        if (this.filters.branch) params.append("branch", this.filters.branch)
        if (this.filters.year) params.append("year", this.filters.year)
        const res = await api.get(`/student/drives?${params.toString()}`)
        if (res.data.success) this.drives = res.data.data
      } catch (err) { console.error(err) }
    },
    async loadApplications() {
      try {
        const res = await api.get("/student/applications")
        if (res.data.success) this.applications = res.data.data
      } catch (err) { console.error(err) }
    },
    async loadProfile() {
      try {
        const res = await api.get("/student/profile")
        if (res.data.success) this.profile = res.data.data
      } catch (err) { console.error(err) }
    },
    toggleProfile() {
      this.showProfile = !this.showProfile
    },
    async updateProfile() {
      this.profileSuccess = false
      this.profileError = ""
      try {
        await api.put("/student/profile", {
          name: this.profile.name,
          branch: this.profile.branch,
          cgpa: this.profile.cgpa,
          year: this.profile.year
        })
        this.profileSuccess = true
      } catch (err) {
        this.profileError = err.response?.data?.message || "Failed to update profile."
      }
    },
    onFileChange(e) {
      this.resumeFile = e.target.files[0]
    },
    async uploadResume() {
      if (!this.resumeFile) return
      const formData = new FormData()
      formData.append("resume", this.resumeFile)
      try {
        await api.post("/student/resume", formData, {
          headers: { "Content-Type": "multipart/form-data" }
        })
        this.resumeSuccess = true
        await this.loadProfile()
      } catch (err) {
        alert(err.response?.data?.message || "Resume upload failed.")
      }
    },
    async apply(driveId) {
      try {
        await api.post(`/application/apply/${driveId}`)
        alert("Applied successfully!")
        await this.loadApplications()
      } catch (err) {
        alert(err.response?.data?.message || "Application failed.")
      }
    },
    async exportApplications() {
      try {
        await api.post("/student/export")
        this.exportMessage = "Export started! You will receive an email shortly."
      } catch (err) {
        this.exportMessage = "Export failed. Please try again."
      }
    },
    clearFilters() {
      this.filters = { search: "", branch: "", year: "" }
      this.loadDrives()
    }
  }
}
</script>