<template>
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card shadow">
        <div class="card-body">
          <h3 class="text-center mb-4">Company Registration</h3>

          <div v-if="message" class="alert alert-success">
            {{ message }}
          </div>

          <div v-if="errorMessage" class="alert alert-danger">
            {{ errorMessage }}
          </div>

          <form @submit.prevent="handleRegister">

            <div class="mb-3">
              <label class="form-label">Contact Name</label>
              <input class="form-control" v-model="form.name" required />
            </div>

            <div class="mb-3">
              <label class="form-label">Email</label>
              <input type="email" class="form-control" v-model="form.email" required />
            </div>

            <div class="mb-3">
              <label class="form-label">Password</label>
              <input type="password" class="form-control" v-model="form.password" required />
            </div>

            <div class="mb-3">
              <label class="form-label">Company Name</label>
              <input class="form-control" v-model="form.company_name" required />
            </div>

            <div class="mb-3">
              <label class="form-label">HR Contact</label>
              <input class="form-control" v-model="form.hr_contact" required />
            </div>

            <div class="mb-3">
              <label class="form-label">Website</label>
              <input class="form-control" v-model="form.website" />
            </div>

            <button class="btn btn-success w-100">Register</button>

          </form>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import api from "../../services/api"

export default {
  name: "RegisterCompanyView",
  data() {
    return {
      form: {
        name: "",
        email: "",
        password: "",
        company_name: "",
        hr_contact: "",
        website: ""
      },
      message: "",
      errorMessage: ""
    }
  },
  methods: {
    async handleRegister() {
      this.message = ""
      this.errorMessage = ""
      try {
        const res = await api.post("/auth/register/company", this.form)
        if (res.data.success) {
          this.$router.push("/login")
        }
      } catch (err) {
        this.errorMessage = err.response?.data?.message || "Registration failed"
      }
    }
  }
}
</script>