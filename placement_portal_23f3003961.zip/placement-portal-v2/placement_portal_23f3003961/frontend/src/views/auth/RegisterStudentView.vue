<template>
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card shadow">
        <div class="card-body">
          <h3 class="text-center mb-4">Student Registration</h3>

          <div v-if="message" class="alert alert-success">
            {{ message }}
          </div>

          <div v-if="errorMessage" class="alert alert-danger">
            {{ errorMessage }}
          </div>

          <form @submit.prevent="handleRegister">

            <div class="mb-3">
              <label class="form-label">Name</label>
              <input class="form-control" v-model="form.name" required />
            </div>

            <div class="mb-3">
              <label class="form-label">Email</label>
              <input type="email" class="form-control" v-model="form.email" required />
            </div>

            <div class="mb-3">
              <label class="form-label">Password</label>
              <input type="password" class="form-control" v-model="form.password" required />
            </div>

            <div class="mb-3">
              <label class="form-label">Branch</label>
              <input class="form-control" v-model="form.branch" required />
            </div>

            <div class="mb-3">
              <label class="form-label">CGPA</label>
              <input type="number" step="0.01" class="form-control" v-model="form.cgpa" required />
            </div>

            <div class="mb-3">
              <label class="form-label">Year</label>
              <input type="number" class="form-control" v-model="form.year" required />
            </div>

            <button class="btn btn-success w-100">Register</button>
          </form>

        </div>
      </div>
    </div>
  </div>
</template>

<script>
import api from "../../services/api"

export default {
  name: "RegisterStudentView",
  data() {
    return {
      form: {
        name: "",
        email: "",
        password: "",
        branch: "",
        cgpa: "",
        year: ""
      },
      message: "",
      errorMessage: ""
    }
  },
  methods: {
    async handleRegister() {
      this.message = ""
      this.errorMessage = ""
      try {
        const res = await api.post("/auth/register/student", this.form)
        if (res.data.success) {
          this.message = "Registration successful. You may now login."
          this.$router.push("/login")
        }
      } catch (err) {
        this.errorMessage = err.response?.data?.message || "Registration failed"
      }
    }
  }
}
</script>