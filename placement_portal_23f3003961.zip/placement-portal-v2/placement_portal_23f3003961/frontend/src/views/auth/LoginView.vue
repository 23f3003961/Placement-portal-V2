<template>
  <div class="row justify-content-center">
    <div class="col-md-5">
      <div class="card shadow">
        <div class="card-body">
          <h3 class="text-center mb-4">Login</h3>

          <div v-if="errorMessage" class="alert alert-danger">
            {{ errorMessage }}
          </div>

          <form @submit.prevent="handleLogin">
            <div class="mb-3">
              <label class="form-label">Email</label>
              <input
                type="email"
                class="form-control"
                v-model="email"
                required
              />
            </div>

            <div class="mb-3">
              <label class="form-label">Password</label>
              <input
                type="password"
                class="form-control"
                v-model="password"
                required
              />
            </div>

            <button class="btn btn-primary w-100" type="submit">
              Login
            </button>
          </form>

          <div class="mt-3 text-center">
            <p class="mb-1">
              Don't have an account?
            </p>
            <router-link to="/register/student" class="me-3">
              Register as Student
            </router-link>
            <router-link to="/register/company">
              Register as Company
            </router-link>
          </div>

        </div>
      </div>
    </div>
  </div>
</template>

<script>
import api from "../../services/api"

export default {
  name: "LoginView",

  data() {
    return {
      email: "",
      password: "",
      errorMessage: ""
    }
  },

  methods: {
    async handleLogin() {
      this.errorMessage = ""

      try {
        const response = await api.post("/auth/login", {
          email: this.email,
          password: this.password
        })

        const token = response.data.token
        const role = response.data.role

        localStorage.setItem("token", token)
        localStorage.setItem("role", role)

        if (role === "ADMIN") {
          this.$router.push("/admin/dashboard")
        } else if (role === "COMPANY") {
          this.$router.push("/company/dashboard")
        } else if (role === "STUDENT") {
          this.$router.push("/student/dashboard")
        }

      } catch (error) {
        if (error.response && error.response.data.message) {
          this.errorMessage = error.response.data.message
        } else {
          this.errorMessage = "Login failed. Please try again."
        }
      }
    }
  }
}
</script>