<!-- Admin Dashboard view -->

<template>
  <div class="container mt-4">
    <h3>Admin Dashboard</h3>

    <!-- Stats -->
    <div v-if="stats" class="row mt-3">
      <div class="col-md-4">
        <div class="card p-3 text-center">
          <h6>Students</h6>
          <h4>{{ stats.total_students }}</h4>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card p-3 text-center">
          <h6>Companies</h6>
          <h4>{{ stats.total_companies }}</h4>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card p-3 text-center">
          <h6>Drives</h6>
          <h4>{{ stats.total_drives }}</h4>
        </div>
      </div>
    </div>

    <hr class="mt-4">

    <!-- Search -->
    <h5>Search Students & Companies</h5>
    <div class="input-group mb-3">
      <input
        type="text"
        class="form-control"
        placeholder="Search by name, email, branch..."
        v-model="searchQuery"
        @input="search"
      />
    </div>
    <div v-if="searchQuery">
      <div v-if="searchResults.students && searchResults.students.length > 0">
        <h6>Students</h6>
        <table class="table table-bordered">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Branch</th>
              <th>CGPA</th>
              <th>Year</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="s in searchResults.students" :key="s.id">
              <td>{{ s.name }}</td>
              <td>{{ s.email }}</td>
              <td>{{ s.branch }}</td>
              <td>{{ s.cgpa }}</td>
              <td>{{ s.year }}</td>
              <td>
                <span :class="s.is_blacklisted ? 'badge bg-danger' : 'badge bg-success'">
                  {{ s.is_blacklisted ? 'Blacklisted' : 'Active' }}
                </span>
              </td>
              <td>
                <button
                  v-if="!s.is_blacklisted"
                  class="btn btn-danger btn-sm"
                  @click="blacklistUser(s.user_id)"
                >Blacklist</button>
                <button
                  v-else
                  class="btn btn-success btn-sm"
                  @click="activateUser(s.user_id)"
                >Activate</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <div v-if="searchResults.companies && searchResults.companies.length > 0">
        <h6>Companies</h6>
        <table class="table table-bordered">
          <thead>
            <tr>
              <th>Company</th>
              <th>HR Contact</th>
              <th>Status</th>
              <th>Blacklisted</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="c in searchResults.companies" :key="c.id">
              <td>{{ c.company_name }}</td>
              <td>{{ c.hr_contact }}</td>
              <td>{{ c.approval_status }}</td>
              <td>
                <span :class="c.is_blacklisted ? 'badge bg-danger' : 'badge bg-success'">
                  {{ c.is_blacklisted ? 'Blacklisted' : 'Active' }}
                </span>
              </td>
              <td>
                <button
                  v-if="!c.is_blacklisted"
                  class="btn btn-danger btn-sm"
                  @click="blacklistUser(c.user_id)"
                >Blacklist</button>
                <button
                  v-else
                  class="btn btn-success btn-sm"
                  @click="activateUser(c.user_id)"
                >Activate</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <div v-if="searchResults.students && searchResults.students.length === 0 && searchResults.companies && searchResults.companies.length === 0">
        <p class="text-muted">No results found.</p>
      </div>
    </div>

    <hr>

    <!-- Pending Company Approvals -->
    <h5>Pending Company Approvals</h5>
    <div v-if="pendingCompanies.length === 0" class="text-muted mb-3">
      No pending companies.
    </div>
    <table v-else class="table table-bordered mt-2">
      <thead>
        <tr>
          <th>Company Name</th>
          <th>HR Contact</th>
          <th>Email</th>
          <th>Website</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="c in pendingCompanies" :key="c.id">
          <td>{{ c.company_name }}</td>
          <td>{{ c.hr_contact }}</td>
          <td>{{ c.email }}</td>
          <td>{{ c.website }}</td>
          <td>
            <button class="btn btn-success btn-sm me-2" @click="approveCompany(c.id)">Approve</button>
            <button class="btn btn-danger btn-sm" @click="rejectCompany(c.id)">Reject</button>
          </td>
        </tr>
      </tbody>
    </table>

    <hr>

    <!-- Pending Drive Approvals -->
    <h5>Pending Drive Approvals</h5>
    <div v-if="pendingDrives.length === 0" class="text-muted mb-3">
      No pending drives.
    </div>
    <table v-else class="table table-bordered mt-2">
      <thead>
        <tr>
          <th>Job Title</th>
          <th>Company</th>
          <th>Branch</th>
          <th>Min CGPA</th>
          <th>Year</th>
          <th>Deadline</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="d in pendingDrives" :key="d.id">
          <td>{{ d.job_title }}</td>
          <td>{{ d.company_name }}</td>
          <td>{{ d.eligibility_branch }}</td>
          <td>{{ d.min_cgpa }}</td>
          <td>{{ d.eligibility_year }}</td>
          <td>{{ new Date(d.deadline).toLocaleDateString() }}</td>
          <td>
            <button class="btn btn-success btn-sm me-2" @click="approveDrive(d.id)">Approve</button>
            <button class="btn btn-danger btn-sm" @click="rejectDrive(d.id)">Reject</button>
          </td>
        </tr>
      </tbody>
    </table>

    <hr>

    <!-- All Students -->
    <h5>All Students</h5>
    <div v-if="students.length === 0" class="text-muted mb-3">No students registered.</div>
    <table v-else class="table table-bordered mt-2">
      <thead>
        <tr>
          <th>Name</th>
          <th>Email</th>
          <th>Branch</th>
          <th>CGPA</th>
          <th>Year</th>
          <th>Status</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="s in students" :key="s.id">
          <td>{{ s.name }}</td>
          <td>{{ s.email }}</td>
          <td>{{ s.branch }}</td>
          <td>{{ s.cgpa }}</td>
          <td>{{ s.year }}</td>
          <td>
            <span :class="s.is_blacklisted ? 'badge bg-danger' : 'badge bg-success'">
              {{ s.is_blacklisted ? 'Blacklisted' : 'Active' }}
            </span>
          </td>
          <td>
            <button
              v-if="!s.is_blacklisted"
              class="btn btn-danger btn-sm"
              @click="blacklistUser(s.user_id)"
            >Blacklist</button>
            <button
              v-else
              class="btn btn-success btn-sm"
              @click="activateUser(s.user_id)"
            >Activate</button>
          </td>
        </tr>
      </tbody>
    </table>

    <hr>

    <!-- All Companies -->
    <h5>All Companies</h5>
    <div v-if="companies.length === 0" class="text-muted mb-3">No companies registered.</div>
    <table v-else class="table table-bordered mt-2">
      <thead>
        <tr>
          <th>Company</th>
          <th>HR Contact</th>
          <th>Email</th>
          <th>Approval Status</th>
          <th>Blacklisted</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="c in companies" :key="c.id">
          <td>{{ c.company_name }}</td>
          <td>{{ c.hr_contact }}</td>
          <td>{{ c.email }}</td>
          <td>{{ c.approval_status }}</td>
          <td>
            <span :class="c.is_blacklisted ? 'badge bg-danger' : 'badge bg-success'">
              {{ c.is_blacklisted ? 'Blacklisted' : 'Active' }}
            </span>
          </td>
          <td>
            <button
              v-if="!c.is_blacklisted"
              class="btn btn-danger btn-sm"
              @click="blacklistUser(c.user_id)"
            >Blacklist</button>
            <button
              v-else
              class="btn btn-success btn-sm"
              @click="activateUser(c.user_id)"
            >Activate</button>
          </td>
        </tr>
      </tbody>
    </table>

    <hr>

    <!-- All Applications -->
    <h5>All Student Applications</h5>
    <div v-if="applications.length === 0" class="text-muted mb-3">No applications yet.</div>
    <table v-else class="table table-bordered mt-2">
      <thead>
        <tr>
          <th>Student</th>
          <th>Email</th>
          <th>Job Title</th>
          <th>Company</th>
          <th>Status</th>
          <th>Applied On</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="a in applications" :key="a.application_id">
          <td>{{ a.student_name }}</td>
          <td>{{ a.student_email }}</td>
          <td>{{ a.job_title }}</td>
          <td>{{ a.company_name }}</td>
          <td>
            <span :class="{
              'badge bg-secondary': a.status === 'APPLIED',
              'badge bg-warning text-dark': a.status === 'SHORTLISTED',
              'badge bg-success': a.status === 'SELECTED',
              'badge bg-danger': a.status === 'REJECTED'
            }">{{ a.status }}</span>
          </td>
          <td>{{ new Date(a.applied_at).toLocaleDateString() }}</td>
        </tr>
      </tbody>
    </table>

  </div>
</template>

<script>
import api from "../../services/api"

export default {
  name: "AdminDashboard",
  data() {
    return {
      stats: null,
      pendingCompanies: [],
      pendingDrives: [],
      students: [],
      companies: [],
      applications: [],
      searchQuery: "",
      searchResults: { students: [], companies: [] }
    }
  },
  async mounted() {
    await this.loadDashboard()
    await this.loadPendingCompanies()
    await this.loadPendingDrives()
    await this.loadStudents()
    await this.loadCompanies()
    await this.loadApplications()
  },
  methods: {
    async loadDashboard() {
      try {
        const res = await api.get("/admin/dashboard")
        if (res.data.success) this.stats = res.data.data
      } catch (err) { console.error(err) }
    },
    async loadPendingCompanies() {
      try {
        const res = await api.get("/admin/companies/pending")
        if (res.data.success) this.pendingCompanies = res.data.data
      } catch (err) { console.error(err) }
    },
    async loadPendingDrives() {
      try {
        const res = await api.get("/admin/drives/pending")
        if (res.data.success) this.pendingDrives = res.data.data
      } catch (err) { console.error(err) }
    },
    async loadStudents() {
      try {
        const res = await api.get("/admin/students")
        if (res.data.success) this.students = res.data.data
      } catch (err) { console.error(err) }
    },
    async loadCompanies() {
      try {
        const res = await api.get("/admin/companies")
        if (res.data.success) this.companies = res.data.data
      } catch (err) { console.error(err) }
    },
    async loadApplications() {
      try {
        const res = await api.get("/admin/applications")
        if (res.data.success) this.applications = res.data.data
      } catch (err) { console.error(err) }
    },
    async search() {
      if (!this.searchQuery) {
        this.searchResults = { students: [], companies: [] }
        return
      }
      try {
        const res = await api.get(`/admin/search?q=${this.searchQuery}`)
        if (res.data.success) this.searchResults = res.data.data
      } catch (err) { console.error(err) }
    },
    async approveCompany(id) {
      await api.put(`/admin/company/${id}/approve`)
      await this.loadPendingCompanies()
      await this.loadCompanies()
      await this.loadDashboard()
    },
    async rejectCompany(id) {
      await api.put(`/admin/company/${id}/reject`)
      await this.loadPendingCompanies()
      await this.loadCompanies()
      await this.loadDashboard()
    },
    async approveDrive(id) {
      await api.put(`/admin/drive/${id}/approve`)
      await this.loadPendingDrives()
      await this.loadDashboard()
    },
    async rejectDrive(id) {
      await api.put(`/admin/drive/${id}/reject`)
      await this.loadPendingDrives()
      await this.loadDashboard()
    },
    async blacklistUser(userId) {
      await api.put(`/admin/user/${userId}/blacklist`)
      await this.loadStudents()
      await this.loadCompanies()
    },
    async activateUser(userId) {
      await api.put(`/admin/user/${userId}/activate`)
      await this.loadStudents()
      await this.loadCompanies()
    }
  }
}
</script>