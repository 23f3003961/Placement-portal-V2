<template>
  <div class="container mt-4">
    <h3>Company Dashboard</h3>

    <div v-if="dashboard">
      <p><strong>Company:</strong> {{ dashboard.company_name }}</p>
      <p><strong>Status:</strong> {{ dashboard.approval_status }}</p>

      <div v-if="dashboard.approval_status === 'PENDING'" class="alert alert-warning mt-3">
        Your company registration is currently <strong>pending approval</strong> from the admin.
        You will be able to create placement drives once approved.
      </div>

      <div v-else-if="dashboard.approval_status === 'REJECTED'" class="alert alert-danger mt-3">
        Your company registration has been <strong>rejected</strong>.
        Please contact the admin for more information.
      </div>

      <div v-else>
        <hr>

        <!-- Create Drive Form -->
        <h5>Create a New Placement Drive</h5>
        <div v-if="createSuccess" class="alert alert-success">
          Drive created successfully! It is pending admin approval.
        </div>
        <div v-if="createError" class="alert alert-danger">{{ createError }}</div>

        <form @submit.prevent="createDrive" class="mb-4">
          <div class="row">
            <div class="col-md-6 mb-3">
              <label class="form-label">Job Title</label>
              <input type="text" class="form-control" v-model="newDrive.job_title" required />
            </div>
            <div class="col-md-6 mb-3">
              <label class="form-label">Eligibility Branch</label>
              <input type="text" class="form-control" v-model="newDrive.eligibility_branch" required />
            </div>
          </div>
          <div class="mb-3">
            <label class="form-label">Job Description</label>
            <textarea class="form-control" v-model="newDrive.description" rows="3" required></textarea>
          </div>
          <div class="row">
            <div class="col-md-4 mb-3">
              <label class="form-label">Minimum CGPA</label>
              <input type="number" step="0.1" min="0" max="10" class="form-control" v-model="newDrive.min_cgpa" required />
            </div>
            <div class="col-md-4 mb-3">
              <label class="form-label">Eligibility Year</label>
              <input type="number" min="1" max="4" class="form-control" v-model="newDrive.eligibility_year" required />
            </div>
            <div class="col-md-4 mb-3">
              <label class="form-label">Application Deadline</label>
              <input type="datetime-local" class="form-control" v-model="newDrive.deadline" required />
            </div>
          </div>
          <button type="submit" class="btn btn-primary">Create Drive</button>
        </form>

        <hr>

        <!-- Drives Table -->
        <h5>Your Drives</h5>
        <div v-if="dashboard.drives.length === 0" class="text-muted">No drives created yet.</div>
        <table v-else class="table table-bordered">
          <thead>
            <tr>
              <th>Title</th>
              <th>Status</th>
              <th>Applicants</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="d in dashboard.drives" :key="d.id">
              <td>{{ d.job_title }}</td>
              <td>{{ d.status }}</td>
              <td>{{ d.applicant_count }}</td>
              <td>
                <button
                  v-if="d.status === 'APPROVED'"
                  class="btn btn-info btn-sm"
                  @click="viewApplications(d.id)"
                >
                  View Applications
                </button>
              </td>
            </tr>
          </tbody>
        </table>

        <!-- Applications for selected drive -->
        <div v-if="selectedDriveId" class="mt-4">
          <h5>Applications for: {{ selectedDriveTitle }}</h5>
          <div v-if="driveApplications.length === 0" class="text-muted">
            No applications yet for this drive.
          </div>
          <table v-else class="table table-bordered">
            <thead>
              <tr>
                <th>Student ID</th>
                <th>Current Status</th>
                <th>Update Status</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="app in driveApplications" :key="app.application_id">
                <td>{{ app.student_id }}</td>
                <td>
                  <span :class="{
                    'badge bg-secondary': app.status === 'APPLIED',
                    'badge bg-warning text-dark': app.status === 'SHORTLISTED',
                    'badge bg-success': app.status === 'SELECTED',
                    'badge bg-danger': app.status === 'REJECTED'
                  }">{{ app.status }}</span>
                </td>
                <td>
                  <div class="d-flex gap-2">
                    <button
                      v-if="app.status === 'APPLIED'"
                      class="btn btn-warning btn-sm"
                      @click="updateStatus(app.application_id, 'SHORTLISTED')"
                    >Shortlist</button>
                    <button
                      v-if="app.status === 'SHORTLISTED'"
                      class="btn btn-success btn-sm"
                      @click="updateStatus(app.application_id, 'SELECTED')"
                    >Select</button>
                    <button
                      v-if="app.status === 'APPLIED' || app.status === 'SHORTLISTED'"
                      class="btn btn-danger btn-sm"
                      @click="updateStatus(app.application_id, 'REJECTED')"
                    >Reject</button>
                    <span v-if="app.status === 'SELECTED' || app.status === 'REJECTED'" class="text-muted small">
                      No further actions
                    </span>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>

      </div>
    </div>

    <div v-else class="text-center mt-5">
      <p>Loading dashboard...</p>
    </div>

  </div>
</template>

<script>
import api from "../../services/api"

export default {
  name: "CompanyDashboard",
  data() {
    return {
      dashboard: null,
      createSuccess: false,
      createError: "",
      newDrive: {
        job_title: "",
        description: "",
        eligibility_branch: "",
        min_cgpa: "",
        eligibility_year: "",
        deadline: ""
      },
      selectedDriveId: null,
      selectedDriveTitle: "",
      driveApplications: []
    }
  },
  async mounted() {
    await this.loadDashboard()
  },
  methods: {
    async loadDashboard() {
      try {
        const res = await api.get("/company/dashboard")
        if (res.data.success) this.dashboard = res.data.data
      } catch (err) { console.error(err) }
    },
    async createDrive() {
      this.createSuccess = false
      this.createError = ""
      try {
        await api.post("/company/drives", {
          job_title: this.newDrive.job_title,
          description: this.newDrive.description,
          eligibility_branch: this.newDrive.eligibility_branch,
          min_cgpa: parseFloat(this.newDrive.min_cgpa),
          eligibility_year: parseInt(this.newDrive.eligibility_year),
          deadline: this.newDrive.deadline
        })
        this.createSuccess = true
        this.newDrive = {
          job_title: "", description: "", eligibility_branch: "",
          min_cgpa: "", eligibility_year: "", deadline: ""
        }
        await this.loadDashboard()
      } catch (err) {
        this.createError = err.response?.data?.message || "Failed to create drive."
      }
    },
    async viewApplications(driveId) {
      this.selectedDriveId = driveId
      const drive = this.dashboard.drives.find(d => d.id === driveId)
      this.selectedDriveTitle = drive ? drive.job_title : ""
      try {
        const res = await api.get(`/company/drive/${driveId}/applications`)
        if (res.data.success) this.driveApplications = res.data.data
      } catch (err) { console.error(err) }
    },
    async updateStatus(applicationId, newStatus) {
      try {
        await api.put(`/company/application/${applicationId}/status`, { status: newStatus })
        await this.viewApplications(this.selectedDriveId)
      } catch (err) {
        alert(err.response?.data?.message || "Failed to update status.")
      }
    }
  }
}
</script>