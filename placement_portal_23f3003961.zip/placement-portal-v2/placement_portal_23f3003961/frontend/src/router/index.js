// all the vue components for the diff routes are imported here.
// they have also been defined in the routes array with path.

import { createRouter, createWebHistory } from 'vue-router'
import LoginView from '../views/auth/LoginView.vue'
import RegisterStudentView from '../views/auth/RegisterStudentView.vue'
import RegistercompanyView from '../views/auth/RegistercompanyView.vue'
import AdminDashboard from '../views/admin/AdminDashboard.vue'
import CompanyDashboard from '../views/company/CompanyDashboard.vue'
import StudentDashboard from '../views/student/StudentDashboard.vue'

const routes = [
  { path: '/', redirect: '/login' },
  { path: '/login', component: LoginView },
  { path: '/register/student', component: RegisterStudentView },
  { path: '/register/company', component: RegistercompanyView },
  {
    path: '/admin/dashboard',
    component: AdminDashboard,
    meta: { role: 'ADMIN' }
  },
  {
    path: '/company/dashboard',
    component: CompanyDashboard,
    meta: { role: 'COMPANY' }
  },
  {
    path: '/student/dashboard',
    component: StudentDashboard,
    meta: { role: 'STUDENT' }
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

router.beforeEach((to, from) => {
  const token = localStorage.getItem('token')
  const role = localStorage.getItem('role')

  if (to.meta.role) {
    if (!token) return '/login'
    if (role !== to.meta.role) return '/login'
  }

  return true
})

export default router