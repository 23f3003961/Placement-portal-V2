from extensions import db
from datetime import datetime
from sqlalchemy import UniqueConstraint


class User(db.Model): # all the users are stored over here.
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(120), nullable=False)
    role = db.Column(db.String(20), nullable=False)  # ADMIN / COMPANY / STUDENT
    is_active = db.Column(db.Boolean, default=True)
    is_blacklisted = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Student(db.Model): # all details of students are stored here
    __tablename__ = "students"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    branch = db.Column(db.String(100), nullable=False)
    cgpa = db.Column(db.Float, nullable=False)
    year = db.Column(db.Integer, nullable=False)
    resume_path = db.Column(db.String(255), nullable=True)


class Company(db.Model): # all details of companies are stored here
    __tablename__ = "companies"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    company_name = db.Column(db.String(120), nullable=False)
    hr_contact = db.Column(db.String(120), nullable=False)
    website = db.Column(db.String(255))
    approval_status = db.Column(db.String(20), default="PENDING")  # PENDING / APPROVED / REJECTED


class PlacementDrive(db.Model): # all details of placement drive are stored here
    __tablename__ = "placement_drives"

    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey("companies.id"), nullable=False)
    job_title = db.Column(db.String(120), nullable=False)
    description = db.Column(db.Text, nullable=False)
    eligibility_branch = db.Column(db.String(120), nullable=False)
    min_cgpa = db.Column(db.Float, nullable=False)
    eligibility_year = db.Column(db.Integer, nullable=False)
    deadline = db.Column(db.DateTime, nullable=False)
    status = db.Column(db.String(20), default="PENDING")  # PENDING / APPROVED / CLOSED


class Application(db.Model): # all details of applications are stored here
    __tablename__ = "applications"

    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("students.id"), nullable=False)
    drive_id = db.Column(db.Integer, db.ForeignKey("placement_drives.id"), nullable=False)
    status = db.Column(db.String(20), default="APPLIED")  # APPLIED / SHORTLISTED / SELECTED / REJECTED
    applied_at = db.Column(db.DateTime, default=datetime.utcnow)

    __table_args__ = (
        UniqueConstraint("student_id", "drive_id", name="unique_student_drive"),
    ) #all unique contraints in the application table are stored here.