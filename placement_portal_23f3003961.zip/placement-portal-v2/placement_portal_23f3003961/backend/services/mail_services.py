from flask_mail import Message
from flask import current_app
from extensions import mail
import os


def send_email(to, subject, html_body, attachment_path=None):
    msg = Message(
        subject=subject,
        recipients=[to],
        html=html_body,
        sender="noreply@placementportal.com"
    )

    if attachment_path and os.path.exists(attachment_path):
        with open(attachment_path, "rb") as f:
            msg.attach(
                filename=os.path.basename(attachment_path),
                content_type="text/csv",
                data=f.read()
            )

    mail.send(msg)