from flask import Blueprint, request, jsonify
from models import db, Company, PlacementDrive, Application, Student
from routes.utils import decode_token
from services.response_services import success_response, error_response
from datetime import datetime

company_routes = Blueprint("company_routes", __name__)

VALID_TRANSITIONS = {
    "APPLIED": ["SHORTLISTED", "REJECTED"],
    "SHORTLISTED": ["SELECTED", "REJECTED"],
    "SELECTED": [],
    "REJECTED": []
}


@company_routes.route("/dashboard", methods=["GET"])
def dashboard():
    user, error = decode_token("COMPANY")
    if error:
        return error_response(error[0], error[1])

    company = Company.query.filter_by(user_id=user.id).first()

    drives = PlacementDrive.query.filter_by(company_id=company.id).all()

    data = []
    for d in drives:
        applicant_count = Application.query.filter_by(drive_id=d.id).count()
        data.append({
            "id": d.id,
            "job_title": d.job_title,
            "status": d.status,
            "applicant_count": applicant_count
        })

    return success_response(
        "Dashboard fetched",
        {
            "company_name": company.company_name,
            "approval_status": company.approval_status,
            "drives": data
        }
    )


@company_routes.route("/drives", methods=["POST"])
def create_drive():
    user, error = decode_token("COMPANY")
    if error:
        return error_response(error[0], error[1])

    company = Company.query.filter_by(user_id=user.id).first()

    if company.approval_status != "APPROVED":
        return error_response("Company not approved", 403)

    data = request.get_json()

    drive = PlacementDrive(
        company_id=company.id,
        job_title=data.get("job_title"),
        description=data.get("description"),
        eligibility_branch=data.get("eligibility_branch"),
        min_cgpa=data.get("min_cgpa"),
        eligibility_year=data.get("eligibility_year"),
        deadline=datetime.fromisoformat(data.get("deadline")),
        status="PENDING"
    )

    db.session.add(drive)
    db.session.commit()

    return success_response("Drive created (Pending Approval)", status_code=201)


@company_routes.route("/drive/<int:drive_id>/applications", methods=["GET"])
def view_applications(drive_id):
    user, error = decode_token("COMPANY")
    if error:
        return error_response(error[0], error[1])

    company = Company.query.filter_by(user_id=user.id).first()
    drive = PlacementDrive.query.get(drive_id)

    if not drive or drive.company_id != company.id:
        return error_response("Drive not found", 404)

    applications = Application.query.filter_by(drive_id=drive_id).all()

    data = []
    for app in applications:
        student = Student.query.get(app.student_id)
        data.append({
            "application_id": app.id,
            "student_id": student.id,
            "status": app.status
        })

    return success_response("Applications fetched", data)


@company_routes.route("/application/<int:application_id>/status", methods=["PUT"])
def update_application_status(application_id):
    user, error = decode_token("COMPANY")
    if error:
        return error_response(error[0], error[1])

    data = request.get_json()
    new_status = data.get("status")

    application = Application.query.get(application_id)
    if not application:
        return error_response("Application not found", 404)

    drive = PlacementDrive.query.get(application.drive_id)
    company = Company.query.filter_by(user_id=user.id).first()

    if drive.company_id != company.id:
        return error_response("Forbidden", 403)

    if new_status not in VALID_TRANSITIONS.get(application.status, []):
        return error_response("Invalid status transition", 400)

    application.status = new_status
    db.session.commit()

    return success_response("Application status updated")