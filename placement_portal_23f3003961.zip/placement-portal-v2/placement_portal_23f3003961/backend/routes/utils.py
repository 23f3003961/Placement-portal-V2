from flask import request, jsonify, current_app
import jwt
from models import User


def decode_token(required_role=None):
    auth_header = request.headers.get("Authorization")

    if not auth_header:
        return None, ("Token missing", 401)

    try:
        token = auth_header.split(" ")[1]
        data = jwt.decode(
            token,
            current_app.config["SECRET_KEY"],
            algorithms=["HS256"]
        )

        user = User.query.get(data["user_id"])
        if not user:
            return None, ("User not found", 404)

        if not user.is_active or user.is_blacklisted:
            return None, ("User inactive or blacklisted", 403)

        if required_role and user.role != required_role:
            return None, ("Forbidden", 403)

        return user, None

    except jwt.ExpiredSignatureError:
        return None, ("Token expired", 401)
    except:
        return None, ("Invalid token", 401)