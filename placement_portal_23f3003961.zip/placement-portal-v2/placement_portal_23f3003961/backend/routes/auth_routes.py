from flask import Blueprint, request, jsonify
from models import db, User, Student, Company
import jwt
from datetime import datetime, timedelta
from flask import current_app

auth_routes = Blueprint("auth_routes", __name__)

def generate_token(user):
    payload = {
        "user_id": user.id,
        "role": user.role,
        "exp": datetime.utcnow() + timedelta(
            seconds=current_app.config["JWT_EXPIRATION_SECONDS"]
        )
    }
    return jwt.encode(payload, current_app.config["SECRET_KEY"], algorithm="HS256")


@auth_routes.route("/login", methods=["POST"])
def login():
    data = request.get_json()

    user = User.query.filter_by(email=data.get("email")).first()

    if not user or user.password != data.get("password"):
        return jsonify({"message": "Invalid credentials"}), 401

    if not user.is_active or user.is_blacklisted:
        return jsonify({"message": "Account inactive or blacklisted"}), 403

    token = generate_token(user)

    return jsonify({
        "token": token,
        "role": user.role
    }), 200


@auth_routes.route("/register/student", methods=["POST"])
def register_student():
    data = request.get_json()

    if User.query.filter_by(email=data.get("email")).first():
        return jsonify({"message": "Email already exists"}), 409

    user = User(
        name=data.get("name"),
        email=data.get("email"),
        password=data.get("password"),
        role="STUDENT"
    )
    db.session.add(user)
    db.session.commit()

    student = Student(
        user_id=user.id,
        branch=data.get("branch"),
        cgpa=data.get("cgpa"),
        year=data.get("year")
    )
    db.session.add(student)
    db.session.commit()

    return jsonify({"message": "Student registered successfully"}), 201


@auth_routes.route("/register/company", methods=["POST"])
def register_company():
    data = request.get_json()

    if User.query.filter_by(email=data.get("email")).first():
        return jsonify({"message": "Email already exists"}), 409

    user = User(
        name=data.get("name"),
        email=data.get("email"),
        password=data.get("password"),
        role="COMPANY"
    )
    db.session.add(user)
    db.session.commit()

    company = Company(
        user_id=user.id,
        company_name=data.get("company_name"),
        hr_contact=data.get("hr_contact"),
        website=data.get("website")
    )
    db.session.add(company)
    db.session.commit()

    return jsonify({"message": "Company registered successfully"}), 201