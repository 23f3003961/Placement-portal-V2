from flask import Blueprint, current_app, request
from models import db, Student, PlacementDrive, Company, Application, User
from routes.utils import decode_token
from services.response_services import success_response, error_response
import os
import uuid
from celery import Celery
from werkzeug.utils import secure_filename

student_routes = Blueprint("student_routes", __name__)

ALLOWED_EXTENSIONS = {"pdf"}

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


@student_routes.route("/drives", methods=["GET"])
def get_approved_drives():
    user, error = decode_token("STUDENT")
    if error:
        return error_response(error[0], error[1])

    branch = request.args.get("branch", "").strip()
    min_cgpa = request.args.get("min_cgpa", "").strip()
    year = request.args.get("year", "").strip()
    search = request.args.get("search", "").lower().strip()

    query = PlacementDrive.query.filter_by(status="APPROVED")

    if branch:
        query = query.filter(PlacementDrive.eligibility_branch == branch)
    if min_cgpa:
        query = query.filter(PlacementDrive.min_cgpa <= float(min_cgpa))
    if year:
        query = query.filter(PlacementDrive.eligibility_year == int(year))

    drives = query.all()

    data = []
    for d in drives:
        company = Company.query.get(d.company_id)
        company_name = company.company_name if company else ""
        if search and search not in d.job_title.lower() and search not in company_name.lower():
            continue
        data.append({
            "id": d.id,
            "job_title": d.job_title,
            "description": d.description,
            "company_name": company_name,
            "eligibility_branch": d.eligibility_branch,
            "min_cgpa": d.min_cgpa,
            "eligibility_year": d.eligibility_year,
            "deadline": d.deadline.isoformat()
        })

    return success_response("Drives fetched", data)


@student_routes.route("/profile", methods=["GET"])
def get_profile():
    user, error = decode_token("STUDENT")
    if error:
        return error_response(error[0], error[1])

    student = Student.query.filter_by(user_id=user.id).first()

    return success_response("Profile fetched", {
        "name": user.name,
        "email": user.email,
        "branch": student.branch,
        "cgpa": student.cgpa,
        "year": student.year,
        "resume_path": student.resume_path
    })


@student_routes.route("/profile", methods=["PUT"])
def update_profile():
    user, error = decode_token("STUDENT")
    if error:
        return error_response(error[0], error[1])

    student = Student.query.filter_by(user_id=user.id).first()
    data = request.get_json()

    if data.get("name"):
        user.name = data.get("name")
    if data.get("branch"):
        student.branch = data.get("branch")
    if data.get("cgpa"):
        student.cgpa = float(data.get("cgpa"))
    if data.get("year"):
        student.year = int(data.get("year"))

    db.session.commit()
    return success_response("Profile updated")


@student_routes.route("/resume", methods=["POST"])
def upload_resume():
    user, error = decode_token("STUDENT")
    if error:
        return error_response(error[0], error[1])

    student = Student.query.filter_by(user_id=user.id).first()

    if "resume" not in request.files:
        return error_response("No file provided", 400)

    file = request.files["resume"]

    if file.filename == "":
        return error_response("No file selected", 400)

    if not allowed_file(file.filename):
        return error_response("Only PDF files are allowed", 400)

    filename = secure_filename(f"resume_{user.id}_{uuid.uuid4().hex}.pdf")
    upload_folder = current_app.config["UPLOAD_FOLDER"]
    os.makedirs(upload_folder, exist_ok=True)
    filepath = os.path.join(upload_folder, filename)
    file.save(filepath)

    student.resume_path = filepath
    db.session.commit()

    return success_response("Resume uploaded successfully")


@student_routes.route("/applications", methods=["GET"])
def get_my_applications():
    user, error = decode_token("STUDENT")
    if error:
        return error_response(error[0], error[1])

    student = Student.query.filter_by(user_id=user.id).first()
    applications = Application.query.filter_by(student_id=student.id).all()

    data = []
    for app in applications:
        drive = PlacementDrive.query.get(app.drive_id)
        company = Company.query.get(drive.company_id) if drive else None
        data.append({
            "application_id": app.id,
            "drive_id": app.drive_id,
            "job_title": drive.job_title if drive else "",
            "company_name": company.company_name if company else "",
            "status": app.status,
            "applied_at": app.applied_at.isoformat()
        })

    return success_response("Applications fetched", data)


@student_routes.route("/export", methods=["POST"])
def export_applications():
    user, error = decode_token("STUDENT")
    if error:
        return error_response(error[0], error[1])

    student = Student.query.filter_by(user_id=user.id).first()

    export_id = str(uuid.uuid4())
    export_path = os.path.join(
        current_app.config["UPLOAD_FOLDER"],
        f"export_{export_id}.csv"
    )
    
    from flask import current_app as flask_app  #imported here to avoid causing error of circular imports.
    celery = Celery(flask_app.import_name, broker=flask_app.config["CELERY_BROKER_URL"])
    celery.send_task(
        "celery_tasks.export_student_applications",
        args=[student.id, export_path]
    )

    return success_response("Export started. You will receive an email once completed.", status_code=202)