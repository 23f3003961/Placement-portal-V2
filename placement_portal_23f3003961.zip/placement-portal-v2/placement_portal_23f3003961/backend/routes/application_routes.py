

from flask import Blueprint, jsonify
from datetime import datetime
from models import db, Application, PlacementDrive, Student
from routes.utils import decode_token

application_routes = Blueprint("application_routes", __name__)

@application_routes.route("/apply/<int:drive_id>", methods=["POST"])
def apply_to_drive(drive_id):
    user, error = decode_token("STUDENT")
    if error:
        return jsonify({"message": error[0]}), error[1]

    student = Student.query.filter_by(user_id=user.id).first()
    drive = PlacementDrive.query.get(drive_id)

    if not drive:
        return jsonify({"message": "Drive not found"}), 404

    if drive.deadline < datetime.utcnow():
        return jsonify({"message": "Application deadline has passed"}), 400

    if drive.status != "APPROVED":
        return jsonify({"message": "Drive is not open for applications"}), 403

    existing = Application.query.filter_by(
        student_id=student.id,
        drive_id=drive.id
    ).first()

    if existing:
        return jsonify({"message": "You have already applied to this drive"}), 409

    errors = []
    if student.branch != drive.eligibility_branch:
        errors.append(f"Branch: your branch is '{student.branch}', required '{drive.eligibility_branch}'")
    if student.cgpa < drive.min_cgpa:
        errors.append(f"CGPA: your CGPA is {student.cgpa}, minimum required is {drive.min_cgpa}")
    if student.year < drive.eligibility_year:
        errors.append(f"Year: your year is {student.year}, required year is {drive.eligibility_year}")

    if errors:
        return jsonify({
            "message": "Eligibility criteria not met: " + " | ".join(errors)
        }), 400

    application = Application(
        student_id=student.id,
        drive_id=drive.id
    )

    db.session.add(application)
    db.session.commit()

    return jsonify({"message": "Application submitted successfully"}), 201