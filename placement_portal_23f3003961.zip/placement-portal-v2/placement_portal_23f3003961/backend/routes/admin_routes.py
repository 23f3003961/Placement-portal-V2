# all the imports for the admin routes are stored here.
# This file contains all the routes related to admin functionalities.

from flask import Blueprint, request
from models import db, User, Company, PlacementDrive, Application, Student
from routes.utils import decode_token
from services.response_services import success_response, error_response
from extensions import cache

admin_routes = Blueprint("admin_routes", __name__)


@admin_routes.route("/dashboard", methods=["GET"])
@cache.cached(timeout=300, key_prefix="admin_dashboard")
def dashboard():
    user, error = decode_token("ADMIN")
    if error:
        return error_response(error[0], error[1])

    total_students = User.query.filter_by(role="STUDENT").count()
    total_companies = User.query.filter_by(role="COMPANY").count()
    total_drives = PlacementDrive.query.count()

    return success_response(
        "Dashboard data",
        {
            "total_students": total_students,
            "total_companies": total_companies,
            "total_drives": total_drives
        }
    )


@admin_routes.route("/companies", methods=["GET"])
def get_companies():
    user, error = decode_token("ADMIN")
    if error:
        return error_response(error[0], error[1])

    companies = Company.query.all()
    data = []
    for c in companies:
        company_user = User.query.get(c.user_id)
        data.append({
            "id": c.id,
            "user_id": c.user_id,
            "company_name": c.company_name,
            "hr_contact": c.hr_contact,
            "website": c.website,
            "approval_status": c.approval_status,
            "email": company_user.email if company_user else "",
            "is_active": company_user.is_active if company_user else True,
            "is_blacklisted": company_user.is_blacklisted if company_user else False
        })

    return success_response("Companies fetched", data)


@admin_routes.route("/companies/pending", methods=["GET"])
def get_pending_companies():
    user, error = decode_token("ADMIN")
    if error:
        return error_response(error[0], error[1])

    companies = Company.query.filter_by(approval_status="PENDING").all()
    data = []
    for c in companies:
        company_user = User.query.get(c.user_id)
        data.append({
            "id": c.id,
            "user_id": c.user_id,
            "company_name": c.company_name,
            "hr_contact": c.hr_contact,
            "website": c.website,
            "email": company_user.email if company_user else ""
        })

    return success_response("Pending companies fetched", data)


@admin_routes.route("/drives/pending", methods=["GET"])
def get_pending_drives():
    user, error = decode_token("ADMIN")
    if error:
        return error_response(error[0], error[1])

    drives = PlacementDrive.query.filter_by(status="PENDING").all()
    data = []
    for d in drives:
        company = Company.query.get(d.company_id)
        data.append({
            "id": d.id,
            "job_title": d.job_title,
            "description": d.description,
            "eligibility_branch": d.eligibility_branch,
            "min_cgpa": d.min_cgpa,
            "eligibility_year": d.eligibility_year,
            "deadline": d.deadline.isoformat(),
            "company_name": company.company_name if company else ""
        })

    return success_response("Pending drives fetched", data)


@admin_routes.route("/drives", methods=["GET"])
def get_all_drives():
    user, error = decode_token("ADMIN")
    if error:
        return error_response(error[0], error[1])

    drives = PlacementDrive.query.all()
    data = []
    for d in drives:
        company = Company.query.get(d.company_id)
        data.append({
            "id": d.id,
            "job_title": d.job_title,
            "company_name": company.company_name if company else "",
            "status": d.status,
            "deadline": d.deadline.isoformat()
        })

    return success_response("All drives fetched", data)


@admin_routes.route("/applications", methods=["GET"])
def get_all_applications():
    user, error = decode_token("ADMIN")
    if error:
        return error_response(error[0], error[1])

    applications = Application.query.all()
    data = []
    for app in applications:
        student = Student.query.get(app.student_id)
        student_user = User.query.get(student.user_id) if student else None
        drive = PlacementDrive.query.get(app.drive_id)
        company = Company.query.get(drive.company_id) if drive else None
        data.append({
            "application_id": app.id,
            "student_name": student_user.name if student_user else "",
            "student_email": student_user.email if student_user else "",
            "job_title": drive.job_title if drive else "",
            "company_name": company.company_name if company else "",
            "status": app.status,
            "applied_at": app.applied_at.isoformat()
        })

    return success_response("All applications fetched", data)


@admin_routes.route("/search", methods=["GET"])
def search():
    user, error = decode_token("ADMIN")
    if error:
        return error_response(error[0], error[1])

    query = request.args.get("q", "").lower()

    students = Student.query.all()
    student_results = []
    for s in students:
        student_user = User.query.get(s.user_id)
        if student_user and (
            query in student_user.name.lower() or
            query in student_user.email.lower() or
            query in s.branch.lower()
        ):
            student_results.append({
                "id": s.id,
                "user_id": s.user_id,
                "name": student_user.name,
                "email": student_user.email,
                "branch": s.branch,
                "cgpa": s.cgpa,
                "year": s.year,
                "is_blacklisted": student_user.is_blacklisted
            })

    companies = Company.query.all()
    company_results = []
    for c in companies:
        company_user = User.query.get(c.user_id)
        if query in c.company_name.lower() or (
            company_user and query in company_user.email.lower()
        ):
            company_results.append({
                "id": c.id,
                "user_id": c.user_id,
                "company_name": c.company_name,
                "hr_contact": c.hr_contact,
                "approval_status": c.approval_status,
                "is_blacklisted": company_user.is_blacklisted if company_user else False
            })

    return success_response("Search results", {
        "students": student_results,
        "companies": company_results
    })


@admin_routes.route("/company/<int:company_id>/approve", methods=["PUT"])
def approve_company(company_id):
    user, error = decode_token("ADMIN")
    if error:
        return error_response(error[0], error[1])

    company = Company.query.get(company_id)
    if not company:
        return error_response("Company not found", 404)

    company.approval_status = "APPROVED"
    db.session.commit()
    cache.clear()

    return success_response("Company approved")


@admin_routes.route("/company/<int:company_id>/reject", methods=["PUT"])
def reject_company(company_id):
    user, error = decode_token("ADMIN")
    if error:
        return error_response(error[0], error[1])

    company = Company.query.get(company_id)
    if not company:
        return error_response("Company not found", 404)

    company.approval_status = "REJECTED"
    db.session.commit()
    cache.clear()

    return success_response("Company rejected")


@admin_routes.route("/drive/<int:drive_id>/approve", methods=["PUT"])
def approve_drive(drive_id):
    user, error = decode_token("ADMIN")
    if error:
        return error_response(error[0], error[1])

    drive = PlacementDrive.query.get(drive_id)
    if not drive:
        return error_response("Drive not found", 404)

    drive.status = "APPROVED"
    db.session.commit()
    cache.clear()

    return success_response("Drive approved")


@admin_routes.route("/drive/<int:drive_id>/reject", methods=["PUT"])
def reject_drive(drive_id):
    user, error = decode_token("ADMIN")
    if error:
        return error_response(error[0], error[1])

    drive = PlacementDrive.query.get(drive_id)
    if not drive:
        return error_response("Drive not found", 404)

    drive.status = "REJECTED"
    db.session.commit()
    cache.clear()

    return success_response("Drive rejected")


@admin_routes.route("/students", methods=["GET"])
def get_students():
    user, error = decode_token("ADMIN")
    if error:
        return error_response(error[0], error[1])

    students = Student.query.all()
    data = []
    for s in students:
        student_user = User.query.get(s.user_id)
        data.append({
            "id": s.id,
            "user_id": s.user_id,
            "name": student_user.name if student_user else "",
            "email": student_user.email if student_user else "",
            "branch": s.branch,
            "cgpa": s.cgpa,
            "year": s.year,
            "is_active": student_user.is_active if student_user else True,
            "is_blacklisted": student_user.is_blacklisted if student_user else False
        })

    return success_response("Students fetched", data)


@admin_routes.route("/user/<int:user_id>/blacklist", methods=["PUT"])
def blacklist_user(user_id):
    user, error = decode_token("ADMIN")
    if error:
        return error_response(error[0], error[1])

    target_user = User.query.get(user_id)
    if not target_user:
        return error_response("User not found", 404)

    target_user.is_blacklisted = True
    target_user.is_active = False
    db.session.commit()
    cache.clear()

    return success_response("User blacklisted")


@admin_routes.route("/user/<int:user_id>/activate", methods=["PUT"])
def activate_user(user_id):
    user, error = decode_token("ADMIN")
    if error:
        return error_response(error[0], error[1])

    target_user = User.query.get(user_id)
    if not target_user:
        return error_response("User not found", 404)

    target_user.is_blacklisted = False
    target_user.is_active = True
    db.session.commit()
    cache.clear()

    return success_response("User activated")