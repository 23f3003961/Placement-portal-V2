from celery import Celery
from models import db, Application, Student, PlacementDrive, User
from flask import Flask
from services.mail_services import send_email
from datetime import datetime, timedelta
import csv
import os


def make_celery(app: Flask):
    celery = Celery(
        app.import_name,
        broker=app.config["CELERY_BROKER_URL"],
        backend=app.config["CELERY_RESULT_BACKEND"]
    )

    celery.conf.update(app.config)

    celery.conf.beat_schedule = {
        'daily_reminder': {
            'task': 'celery_tasks.daily_deadline_reminder',
            'schedule': 86400.0
        },
        'monthly_report': {
            'task': 'celery_tasks.monthly_admin_report',
            'schedule': 2592000.0
        }
    }

    class ContextTask(celery.Task):
        def __call__(self, *args, **kwargs):
            with app.app_context():
                return self.run(*args, **kwargs)

    celery.Task = ContextTask
    return celery


def register_tasks(celery):

    @celery.task()
    def export_student_applications(student_id, export_path):
        os.makedirs(os.path.dirname(export_path), exist_ok=True)

        applications = Application.query.filter_by(student_id=student_id).all()

        with open(export_path, "w", newline="") as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(["Student ID", "Company Name", "Drive Title", "Application Status", "Applied At"])

            for app in applications:
                drive = PlacementDrive.query.get(app.drive_id)
                from models import Company
                company = Company.query.get(drive.company_id) if drive else None
                writer.writerow([
                    student_id,
                    company.company_name if company else "",
                    drive.job_title if drive else "",
                    app.status,
                    app.applied_at
                ])

        student = Student.query.get(student_id)
        user = User.query.get(student.user_id)

        send_email(
            user.email,
            "Placement Applications Export",
            "<h3>Your export is ready. Please find your application history attached.</h3>",
            export_path
        )

    @celery.task()
    def daily_deadline_reminder():
        upcoming = datetime.utcnow() + timedelta(days=3)
        drives = PlacementDrive.query.filter(
            PlacementDrive.deadline <= upcoming,
            PlacementDrive.deadline > datetime.utcnow()
        ).all()

        for drive in drives:
            applications = Application.query.filter_by(drive_id=drive.id).all()
            for app in applications:
                student = Student.query.get(app.student_id)
                user = User.query.get(student.user_id)
                send_email(
                    user.email,
                    "Upcoming Deadline Reminder",
                    f"<p>The drive <strong>{drive.job_title}</strong> closes on {drive.deadline.strftime('%Y-%m-%d')}. Don't miss it!</p>"
                )

    @celery.task()
    def monthly_admin_report():
        total_drives = PlacementDrive.query.count()
        total_apps = Application.query.count()
        selected = Application.query.filter_by(status="SELECTED").count()

        html = f"""
        <h2>Monthly Placement Report</h2>
        <p>Total Drives Conducted: {total_drives}</p>
        <p>Total Applications: {total_apps}</p>
        <p>Total Students Selected: {selected}</p>
        """

        admin = User.query.filter_by(role="ADMIN").first()

        send_email(
            admin.email,
            "Monthly Placement Report",
            html
        )