from flask import Flask, request, jsonify
from flask_cors import CORS
from config import Config
from extensions import db, mail, cache
from models import User
from routes.auth_routes import auth_routes
from routes.admin_routes import admin_routes
from routes.company_routes import company_routes
from routes.student_routes import student_routes
from routes.application_routes import application_routes
from celery_app import make_celery
from celery_tasks import register_tasks

app = Flask(__name__)
app.config.from_object(Config)

CORS(app)

@app.after_request
def add_cors_headers(response):
    response.headers["Access-Control-Allow-Origin"] = "http://localhost:5173"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization"
    response.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, OPTIONS"
    response.headers["Access-Control-Allow-Credentials"] = "true"
    return response

@app.before_request
def handle_options():
    if request.method == "OPTIONS":
        response = jsonify({})
        response.status_code = 200
        return response

@app.errorhandler(500)
def handle_500(e):
    response = jsonify({"success": False, "message": "Internal server error"})
    response.status_code = 500
    return response

db.init_app(app)
mail.init_app(app)
cache.init_app(app)

def create_admin():
    existing_admin = User.query.filter_by(role="ADMIN").first()
    if not existing_admin:
        admin = User(
            name="Aryaman",
            email="admin@abc.com",
            password="admin",
            role="ADMIN"
        )
        db.session.add(admin)
        db.session.commit()

app.register_blueprint(auth_routes, url_prefix="/api/auth")
app.register_blueprint(admin_routes, url_prefix="/api/admin")
app.register_blueprint(company_routes, url_prefix="/api/company")
app.register_blueprint(student_routes, url_prefix="/api/student")
app.register_blueprint(application_routes, url_prefix="/api/application")

with app.app_context():
    db.create_all()
    create_admin()

celery = make_celery(app)
register_tasks(celery)

if __name__ == "__main__":
    app.run(debug=True, port=5001)